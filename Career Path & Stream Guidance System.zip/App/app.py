from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

model = joblib.load("model.pkl")
encoder = joblib.load("encoder.pkl")
features = joblib.load("features.pkl")

NEXT_STEPS_GUIDE = {
    "Engineering & Technology (PCM)": [
        "Strengthen advanced Mathematics and Physics fundamentals.",
        "Take up introductory coding tutorials or hands-on electronics kits.",
        "Research engineering entrance roadmaps (e.g., JEE, State Technical Exams)."
    ],
    "Medical & Allied Health Sciences (PCB)": [
        "Focus on deep conceptual clarity in Botany, Zoology, and Chemistry.",
        "Explore related medical tracks including Biotechnology, Pharmacy, and Nursing.",
        "Prepare a consistent revision schedule for medical entrance exams."
    ],
    "Commerce, Finance & Chartered Careers": [
        "Build a solid grasp of Accountancy, Business Studies, and Statistics.",
        "Familiarize yourself with basic financial spreadsheets and market economics.",
        "Explore professional career paths such as CA, CS, CFA, or BBA/B.Com Honours."
    ],
    "Law, Public Policy & Humanities": [
        "Read editorial analyses, newspapers, and practice critical reasoning daily.",
        "Participate in debates, writing competitions, and public speaking forums.",
        "Explore entrance exams for Law (such as CLAT) or premier Liberal Arts programs."
    ],
    "Creative Arts, Design & Media": [
        "Maintain a personal creative portfolio of sketches, UI designs, or digital artwork.",
        "Learn industry software tools like Figma, Illustrator, or 3D modeling packages.",
        "Check eligibility criteria for Design institutes (such as NID, UCEED, or NIFT)."
    ],
    "Vocational & Practical Trades": [
        "Opt for hands-on polytechnic diplomas or practical skill-certified programs.",
        "Engage in technical workshops focusing on electronics, machining, or computing hardware.",
        "Look into lateral-entry degree options available after completing a diploma."
    ]
}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json() or {}
    
    # Read all 10 features with safe defaults
    row = {f: float(data.get(f, 50.0)) for f in features}
    user_df = pd.DataFrame([row], columns=features)
    
    # Model inference
    probabilities = model.predict_proba(user_df)[0]
    classes = encoder.classes_
    
    pred_idx = model.predict(user_df)[0]
    career = encoder.inverse_transform([pred_idx])[0]
    confidence = float(max(probabilities) * 100)
    
    # Full probability spread across all 6 options
    breakdown = {cls: round(float(prob * 100), 1) for cls, prob in zip(classes, probabilities)}
    guidance = NEXT_STEPS_GUIDE.get(career, ["Explore domain certification and counseling."])
    
    return jsonify({
        "career": career,
        "confidence": round(confidence, 1),
        "breakdown": breakdown,
        "next_steps": guidance
    })

if __name__ == "__main__":
    app.run(debug=True, port=5001)