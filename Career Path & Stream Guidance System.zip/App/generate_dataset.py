import numpy as np
import pandas as pd

np.random.seed(42)

def generate_profile(career, stage):
    # Generates scores (0-100) reflecting natural strengths for each domain
    # Noise added to ensure real-world variance
    if career == "Engineering & Technology (PCM)":
        return {
            "Maths_Score": np.random.randint(75, 100),
            "Science_Score": np.random.randint(70, 98),
            "Biology_Score": np.random.randint(20, 55),
            "Humanities_Score": np.random.randint(30, 65),
            "Commerce_Score": np.random.randint(30, 65),
            "Logical_Reasoning": np.random.randint(75, 100),
            "Tech_Aptitude": np.random.randint(70, 100),
            "Creative_Design": np.random.randint(25, 65),
            "Communication": np.random.randint(45, 80),
            "Academic_Stage": stage,
            "Target_Career": career
        }
    elif career == "Medical & Allied Health Sciences (PCB)":
        return {
            "Maths_Score": np.random.randint(45, 75),
            "Science_Score": np.random.randint(75, 98),
            "Biology_Score": np.random.randint(80, 100),
            "Humanities_Score": np.random.randint(35, 70),
            "Commerce_Score": np.random.randint(20, 50),
            "Logical_Reasoning": np.random.randint(65, 90),
            "Tech_Aptitude": np.random.randint(20, 55),
            "Creative_Design": np.random.randint(20, 60),
            "Communication": np.random.randint(60, 90),
            "Academic_Stage": stage,
            "Target_Career": career
        }
    elif career == "Commerce, Finance & Chartered Careers":
        return {
            "Maths_Score": np.random.randint(70, 95),
            "Science_Score": np.random.randint(30, 65),
            "Biology_Score": np.random.randint(15, 45),
            "Humanities_Score": np.random.randint(50, 80),
            "Commerce_Score": np.random.randint(80, 100),
            "Logical_Reasoning": np.random.randint(70, 95),
            "Tech_Aptitude": np.random.randint(30, 65),
            "Creative_Design": np.random.randint(20, 55),
            "Communication": np.random.randint(65, 90),
            "Academic_Stage": stage,
            "Target_Career": career
        }
    elif career == "Law, Public Policy & Humanities":
        return {
            "Maths_Score": np.random.randint(35, 70),
            "Science_Score": np.random.randint(30, 65),
            "Biology_Score": np.random.randint(20, 50),
            "Humanities_Score": np.random.randint(80, 100),
            "Commerce_Score": np.random.randint(40, 75),
            "Logical_Reasoning": np.random.randint(70, 95),
            "Tech_Aptitude": np.random.randint(20, 50),
            "Creative_Design": np.random.randint(40, 75),
            "Communication": np.random.randint(80, 100),
            "Academic_Stage": stage,
            "Target_Career": career
        }
    elif career == "Creative Arts, Design & Media":
        return {
            "Maths_Score": np.random.randint(30, 65),
            "Science_Score": np.random.randint(25, 60),
            "Biology_Score": np.random.randint(20, 50),
            "Humanities_Score": np.random.randint(60, 85),
            "Commerce_Score": np.random.randint(30, 65),
            "Logical_Reasoning": np.random.randint(55, 80),
            "Tech_Aptitude": np.random.randint(40, 75),
            "Creative_Design": np.random.randint(85, 100),
            "Communication": np.random.randint(70, 95),
            "Academic_Stage": stage,
            "Target_Career": career
        }
    elif career == "Vocational & Practical Trades":
        return {
            "Maths_Score": np.random.randint(40, 70),
            "Science_Score": np.random.randint(50, 75),
            "Biology_Score": np.random.randint(20, 50),
            "Humanities_Score": np.random.randint(30, 60),
            "Commerce_Score": np.random.randint(30, 60),
            "Logical_Reasoning": np.random.randint(50, 75),
            "Tech_Aptitude": np.random.randint(75, 95),
            "Creative_Design": np.random.randint(40, 75),
            "Communication": np.random.randint(40, 70),
            "Academic_Stage": stage,
            "Target_Career": career
        }

careers = [
    "Engineering & Technology (PCM)",
    "Medical & Allied Health Sciences (PCB)",
    "Commerce, Finance & Chartered Careers",
    "Law, Public Policy & Humanities",
    "Creative Arts, Design & Media",
    "Vocational & Practical Trades"
]

rows = []
for career in careers:
    # 50 records for after-10th (stage=0), 50 records for after-12th (stage=1)
    for _ in range(50):
        rows.append(generate_profile(career, stage=0))
    for _ in range(50):
        rows.append(generate_profile(career, stage=1))

df = pd.DataFrame(rows)
df = df.sample(frac=1.0, random_state=42).reset_index(drop=True)
df.to_csv("career_guidance_dataset.csv", index=False)

print("Generated career_guidance_dataset.csv successfully with shape:", df.shape)
print("\nSample records:")
print(df.head(3))
