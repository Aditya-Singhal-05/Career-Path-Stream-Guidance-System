import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# 1. Load Dataset
df = pd.read_csv("career_guidance_dataset.csv")

X = df.drop("Target_Career", axis=1)
y = df["Target_Career"]

# 2. Encode Labels
encoder = LabelEncoder()
y_encoded = encoder.fit_transform(y)

# 3. Train / Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)

# 4. Train with max_features='sqrt' to ensure prediction sensitivity
model = RandomForestClassifier(
    n_estimators=150,
    max_features="sqrt",
    max_depth=10,
    min_samples_split=4,
    random_state=42
)
model.fit(X_train, y_train)

# 5. Evaluate
y_pred = model.predict(X_test)
print("\n--- Model Evaluation on Test Set ---")
print(classification_report(y_test, y_pred, target_names=encoder.classes_))

# 6. Save Artifacts
joblib.dump(model, "model.pkl")
joblib.dump(encoder, "encoder.pkl")
joblib.dump(list(X.columns), "features.pkl")
print("Saved model.pkl, encoder.pkl, and features.pkl successfully.")